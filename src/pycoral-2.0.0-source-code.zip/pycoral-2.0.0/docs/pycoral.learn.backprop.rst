pycoral.learn.backprop
======================

pycoral.learn.backprop.softmax_regression
-----------------------------------------

.. automodule:: pycoral.learn.backprop.softmax_regression
    :members:
    :undoc-members:
    :inherited-members: