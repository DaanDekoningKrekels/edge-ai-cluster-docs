pycoral.pipeline
================

pycoral.pipeline.pipelined_model_runner
---------------------------------------

.. automodule:: pycoral.pipeline.pipelined_model_runner
    :members:
    :undoc-members:
    :inherited-members:
