pycoral.utils
=============

pycoral.utils.dataset
---------------------

.. automodule:: pycoral.utils.dataset
    :members:
    :undoc-members:
    :inherited-members:


pycoral.utils.edgetpu
---------------------

.. automodule:: pycoral.utils.edgetpu
    :members:
    :undoc-members:
    :inherited-members:
    :imported-members: